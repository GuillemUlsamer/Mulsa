Implement Screen 3 of Mulsa, "Inside the record" (the Runner), and the opening animation from Screen 2, in our Angular app. Screens 1 and 2 are already implemented; follow the design handoff in this folder.

- Read `README.md` first: timeline, lid/hinge CSS, disc and tray specs, Runner layout, colours.
- Open `reference.html` in a browser: it is a working, dependency-free reference. Press Open (or Enter), then Run, Stop, ‹ Playlists / Esc. `?t=360` freezes a frame of the animation; `?state=running` or `?state=finished` opens those states directly. Match it at 1440×900 and 1200×700.
- "Open" in the Selected-record panel starts the 900 ms opening; "‹ Playlists" and Esc play it in reverse and return to Screen 2 with the same record selected.
- Animation: drive it from one clock (requestAnimationFrame or Angular animations). Use the 3D lid (rotateY around the left edge) until 620 ms, then swap to flat rects that grow into the two columns. No WebGL, no libraries.
- Runner: build it as an Angular component (e.g. `RunnerComponent`) with the app's existing header (playlist name as title; ‹ Playlists / Setup / Delete, Setup and Delete hidden while running) and footer.
  - Left column: the track list of the selected volume, with status marks.
  - Below it, volume tabs that wrap to two rows and then scroll (up to 40 volumes).
  - Right column: idle summary with Run → live log with Stop / Copy log → finished with a "To review" box.
- Data: playlist name, year, volumes with tracks (marked flag and download status), marked and downloaded counts, cover image (lid front and disc label). Log lines and track statuses come from the existing run events from the backend; map them to Searching / Downloading N% / Converting / Done / Verify / Failed.
- Status colours (#1E8E5A, #B7791F, #D93025) only on marks and status words. Keep everything else in the app's neutral palette.
- When done, run the app, check there are no console errors, and compare against `reference.html` side by side.
