# Handoff: Mulsa · Inside the record (Runner, Screen 3) + opening animation

## Overview
Pressing **Open** on Screen 2 ("Selected record") opens the jewel case. The lid swings open to the left and reveals the booklet and the CD. The open case then grows into the Runner screen: the booklet becomes the left column (track list per volume) and the disc side becomes the right column (summary and Run, then the live log). Closing ("‹ Playlists" or Esc) plays the same animation in reverse. Target sizes: 1440×900 (primary), 1200×700 (must work).

## About the design files
These are **design references made in HTML**, not production code. Rebuild them in the existing Angular app on top of Screens 1 and 2, which are already implemented.
- `reference.html` is a dependency-free working version. It starts on a stand-in for Screen 2 (scrim + panel; your real shelf sits behind it). Press **Open** or Enter to play the animation, then Run, Stop and ‹ Playlists / Esc.
  - `?t=360` freezes the timeline at that ms (0–900).
  - `?state=idle|running|finished` opens directly in that state.
  - It is the source of truth for values and timing.
- The `.dc.html` files are the design canvas (frames 3a–3h) and are for reference only.
- Note: some screenshot tools ignore `backface-visibility` and show the booklet mirrored on the closed case. Real browsers render it correctly.

## Fidelity
High fidelity. The cover art, disc label, track names and run log are placeholders. Use the real cover image for the lid front and the disc label, and the real run events for the log.

## Part A · Opening animation (900 ms; close = exact reverse)
All motion is a function of one clock `t`; `reference.html → layout(t)` has the exact maths.

| t (ms) | What happens | Easing |
|---|---|---|
| 0–200 | Info panel, ×, arrows fade out (panel also translateX 0→12px) | linear / ease-out |
| 0–500 | Case moves from its Screen 2 spot (group centred: left = (W−796)/2) until its **left edge (hinge) is on the window centre**; untilts rotateX(3deg) rotateY(−8deg) → 0 | cubic in-out |
| 120–500 | Lid rotateY 0 → −150deg | cubic in-out |
| 500–620 | Lid −150 → −180deg (flat open) | cubic out |
| 620 | 3D case is swapped for two flat rects at identical positions: booklet (left of centre) and tray + disc (right of centre) | – |
| 620–900 | Booklet rect → left column (0, 64, 40%W, H−123). Tray rect → idle tray spot. Page bg, header and footer fade in. The small printed booklet fades out in the first third. | cubic out |
| 820–900 | Column content (track list, tabs, info panel) fades in | linear |

Key frames in the canvas: **3a** 250ms, **3b** 360ms, **3c** 620ms, **3d** 760ms, **3e** 900ms (idle).

### Lid / hinge CSS
```css
.scene { position:absolute; inset:0; perspective:2000px; perspective-origin:50% 50%; }
.case  { position:absolute; width:420px; height:420px; transform-style:preserve-3d;
         transform: rotateX(3deg) rotateY(-8deg); /* → none during 0–500ms */ }
.edge.t { top:202px; width:420px; height:16px; background:#E8EAED; transform:rotateX(90deg)  translateZ(210px); }
.edge.b { top:202px; width:420px; height:16px; background:#C3C7CC; transform:rotateX(-90deg) translateZ(210px); }
.edge.l { left:202px; width:16px; height:420px; background:#C3C7CC; transform:rotateY(-90deg) translateZ(210px); }
.edge.r { left:202px; width:16px; height:420px; background:#C3C7CC; transform:rotateY(90deg)  translateZ(210px); }
.tray-face { position:absolute; inset:0; transform:translateZ(-6px); }      /* tray + disc */
.lid       { position:absolute; inset:0; transform-style:preserve-3d;
             transform-origin:0 50%;                                       /* left hinge */
             transform:translateZ(8px) rotateY(var(--a)); }               /* --a: 0 → -180deg */
.lid-face  { position:absolute; inset:0; backface-visibility:hidden; }
.lid-front { /* cover image */ }
.lid-back  { transform:rotateY(180deg); background:#ECEEF1; }             /* booklet */
```
Floor shadow under the case: rgba(20,24,32,.50), blur 22px, 40px high, widens with the lid (`left = caseLeft − 420·open + 30`, `width = 420·(1+open) − 60`, open = −a/180).

### Disc (can be one inline SVG, viewBox 0 0 100 100)
- Disc: circle r50, fill #D7DADF, drop shadow 0 2px 8px rgba(31,36,46,.25).
- Label: the cover image clipped to the circle (playlist name centred around y≈70, 900 italic uppercase, when using generated art).
- Rainbow: conic overlay with four soft hues at .20–.22 alpha (rgba(255,170,120), (120,200,255), (200,140,255), (160,255,190)), separated by transparent stops, `mix-blend-mode: screen`. Keep it subtle. In SVG, use a few low-opacity wedge paths.
- Rim: inner ring 2px rgba(255,255,255,.55), then 1px rgba(0,0,0,.10).
- Clear hub: circle r17 #E9EBEE with a 1px rgba(0,0,0,.08) ring. Hole: r6 #C9CDD2 with inner shadow.
- Disc size = 88% of the tray, inset 6%.

### Tray
#E3E5E8 with a 1px #C9CDD2 border. It contains:
- Ring: 94% circle #DADDE1, `inset 0 1px 3px rgba(31,36,46,.18)`.
- Thumb notches: left/right edges, 4%×16% at 42% from the top, #D0D3D8, rounded on the inner side.
- Hinge clips: 2.5%×9% #CDD1D6 with a 1px #BFC4CA border, on the left edge at 6% from the top and bottom.
- Centre hub: 22% circle #CDD1D6 with a 1px #BFC4CA border.

## Part B · Runner screen
### Header (64px) and footer (59px)
- Header: the app's header with the **playlist name** as the 30px/700 title (ellipsis). Actions: "‹ Playlists", "Setup", "Delete". Setup and Delete are hidden while running.
- Footer: one 13px #5B6472 line.
  - Idle: "16 volumes · 176 marked · 131 downloaded".
  - Running: "Running · 3 of 34 pending songs processed".
  - Finished: adds "· last run: N to verify, N failed".

### Left column, "booklet" (40% of width)
Background #ECEEF1, 1px #DBE0E6 right border.
- Volume head: padding 20px 32px 12px, 1px #D5D9DE bottom rule. "Vol. 3" 20px/700; right side "18 tracks · 14 marked" 13px #5B6472.
- Track rows: 30px tall, padding 0 32px, 1px #DDE0E4 rule. Grid 28px | 1fr | 16px, gap 8px.
  - Number: 12px #8A93A0 tabular-nums.
  - Text: "Artist – Title", 14px, ellipsis.
  - Colour: marked rows #1F242E, unmarked rows #8A93A0.
- Status marks (16px):
  - Downloaded: check, stroke #1E8E5A 2px.
  - Verify: check in #B7791F plus a 2.2px #B7791F dot at the top-right.
  - Failed: cross #D93025.
  - Downloading: 12px ring spinner (2px #DBE0E6, top #1F242E, 0.8s linear).
  - None: empty.
- Volume selector: 1px #D5D9DE top rule, padding 12px 32px 14px. Wrapping row of tabs "V 1"… with 4px gap, max-height 52px (two rows), then scrolls vertically. Handles 40+ volumes.
  - Tab: 24px tall, min-width 36px, 12px tabular-nums, radius 2px. Inactive: #F9F9FA bg, 1px #DBE0E6. Active: #1F242E bg and border, white text.
- While running, the column follows the volume being processed until the user picks a tab.

### Right column (60%)
- **Idle**: tray and info are centred as a group with a 40px gap.
  - Tray size = `max(240, min(420, colH − 96, colW − 376))`; disc inside.
  - Info (≤320px wide) is the same block as the Screen 2 panel, without the card: name 32px/700, "1996 · 16 volumes" 16px #5B6472, Marked songs / Downloaded rows, 4px progress bar, and **Run** (primary).
- **Running**:
  - The tray fades out (240ms). The disc shrinks and moves to the top-right of the column (40px, 16px below the header, 32px from the right; 420ms `cubic-bezier(.2,.7,.2,1)`) and spins (1.8s linear).
  - Status bar: 72px, padding 0 32px, 1px #DBE0E6 bottom rule.
    - Title "Running" 18px/700.
    - Sub-line 13px #5B6472: "Vol. 2 of 16 · Artist – Title".
    - Buttons: **Stop** (primary) and **Copy log**, followed by a 40px slot reserved for the disc.
  - Log: padding 12px 32px 24px, auto-scrolls to the bottom.
    - Each line is a grid 60px | 1fr | auto, gap 12px, 13px / 24px.
    - Time: #8A93A0 tabular-nums.
    - Plain lines: #5B6472.
    - Song lines: text #1F242E, one line per song, updated in place as its status changes.
    - Status words: "Searching", "Downloading 45%", "Converting" in #5B6472 / #1F242E. Only these are coloured, at 700: "Done" #1E8E5A, "Verify · 192 kbps" #B7791F, "Failed · no results" #D93025. A song interrupted by Stop reads "Stopped".
- **Finished**: title "Finished" (or "Stopped"); sub-line "N downloaded · N to verify · N failed".
  - Buttons: Copy log and **Run**. The disc stops spinning.
  - A **To review** box sits above the log: white, 1px #DBE0E6, radius 2px, margin 16px 32px 0.
    - Head: "To review" 14px/700 and the count 13px #5B6472.
    - List: max-height 150px, scrolls. Rows are a grid 52px | 64px | 1fr at 13px / 26px: the word "Verify"/"Failed" (700, status colour), the reference "V 1 · 01" in #8A93A0, then "Artist – Title".

### State
- Route state: `open: 0..900` (animation clock) or a boolean plus an animation driver.
- `runState`: idle | running | finished.
- `stoppedByUser`: boolean.
- `selectedVolume`: null = follow the run.
- Track status per song: none | busy | done | verify | failed. Log lines come from the backend run events.

## Design tokens
- Font: Roboto Condensed 400/700 (900 italic only in placeholder art).
- Bg #F9F9FA · Text #1F242E · Muted #5B6472 · Faint #8A93A0 · Border #DBE0E6 · Paper #ECEEF1 · Rows #DDE0E4 / #D5D9DE.
- Case top #E8EAED · Case sides #C3C7CC · Tray #E3E5E8 / #DADDE1 / #CDD1D6 / #C9CDD2 · Disc #D7DADF · Hub #E9EBEE.
- Status: done #1E8E5A · verify #B7791F · failed #D93025. Use them only for marks and status words.
- Radius 2px on UI. Buttons 24px (primary min-width 72px, padding 0 14px).

## Files
- `reference.html`: standalone working reference (Screen 2 stand-in → opening animation → Runner idle/running/finished).
- `Mulsa Playlists.dc.html`, `Shelf Screen.dc.html`, `Runner Screen.dc.html`, `support.js`: design canvas (frames 3a–3h). Reference only.
