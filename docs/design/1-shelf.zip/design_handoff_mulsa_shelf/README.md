# Handoff: Mulsa · Playlists shelf (Screen 1)

## Overview
Main screen of Mulsa (Windows desktop app, Python + Angular in a native window, usually maximized). Each playlist is shown as a physical record standing on a wooden shelf, with a supermarket-style price tag under it. Target sizes: 1440×900 (primary) and 1200×700 (must still work).

## About the design files
The files in this folder are **design references made in HTML**, not production code. Rebuild the screen in the existing Angular app using its components and patterns. `shelf-reference.html` is a dependency-free, working vanilla HTML/CSS/JS version (open it in a browser) — use it as the exact source of truth for values and the 3D CSS. The `.dc.html` files are the original design canvas and need the design tool's runtime; you don't need them.

## Fidelity
High fidelity. Reproduce colors, sizes, 3D and shadows exactly. Only the covers are placeholders: use the playlist's real cover image.

## Layout (top to bottom)
1. **Header** — 48px tall, padding 0 16px, 1px bottom border #DBE0E6.
   - Left: kangaroo mascot 24×24 (asset from the app), 8px gap, "Mulsa" 18px/700.
   - Right, 6px gap: buttons "New playlist" (primary), "Add from Google", "Import xlsx", "Settings".
2. **Shelves** — fills remaining height, scrolls vertically (overflow-x hidden). Padding 4px 48px 48px.
3. **Footer** — 32px tall, padding 0 16px, 1px top border #DBE0E6. Left: "N playlists" 12px #5B6472. Right: "Refresh" button.

## Shelf geometry
- `W` = shelves container width − 96 (side padding).
- Records per shelf: `per = clamp(floor(W / (176 + 44)), 4, 6)` → 6 at 1440, 5 at 1200. Max is 6.
- Slot width `slotW = W / per`; each record is centred in its slot. Playlists fill shelves left to right; the last shelf may be partly empty (board still full width).
- Per row (all y relative to row top): cover size S = 176, top padding 40, record base `B = 216`, row height 310.
  - **Back panel**: x from −12px to +12px beyond content (aligned with the back edge of the board top), y from `0` (first row) or `−34px` (other rows, so it reaches the board above) down to `B − 10 = 206`. Background #E6D6C3. First row: 1px top border #CDB89F. Other rows: `box-shadow: inset 0 12px 14px -8px rgba(74,46,24,.28)` (shadow under the board above).
  - **Board top**: x −24px…+24px beyond content, y 206, height 18, #A67C58, trapezoid `clip-path: polygon(12px 0, calc(100% - 12px) 0, 100% 100%, 0 100%)`.
  - **Board front**: x −24…+24, y 224, height 52, #8B6243, border-top 1px #B48C69, border-bottom 1px #6B4A32, `box-shadow: 0 8px 14px -6px rgba(31,36,46,.12)`.
  - **Price tag**: width `min(slotW − 20, 184)`, height 42, y 229, centred under the record. #FFFFFF, 1px #DBE0E6, radius 2px, padding 5px 7px.
    - Line 1: playlist name 13px/700, line-height 15px, single line with ellipsis.
    - Line 2 (space-between): year 12px/400 #5B6472; volume count "1 vol." / "3 vols." 12px/700, padding 0 4px, 1px #1F242E border, radius 2px.

## 3D record (plain CSS, no WebGL)
- Each slot: `perspective: 900px; perspective-origin: (slotW/2 + (W/2 − slotCenterX))px -260px` → all records share one viewpoint above the centre of the shelf, so left records show their right spine and vice versa.
- Record: `position:absolute; top:40px; width/height:176px; transform-style:preserve-3d; transform-origin:50% 100%`.
- Faces (depth 7px):
  - Front: cover image, `box-shadow: inset 0 0 0 1px rgba(0,0,0,.18)`.
  - Top edge: width 100%, height 7px, `transform-origin:50% 0; transform:rotateX(-90deg); filter:brightness(1.25) saturate(.7)`.
  - Left edge: width 7px, height 100%, left 0, `transform-origin:0 50%; transform:rotateY(90deg); filter:brightness(.62)`.
  - Right edge: same, right 0, `transform-origin:100% 50%; transform:rotateY(-90deg)`.
  - Edge background: the cover's dominant color (or the cover image itself stretched).
- Stacking inside the slot: tag z 1, cast shadow z 2, record z 3.

## Shadows
- **Cast shadow** (falls on the board and top of the tag): div at x = record left + 4, y = B − 14, width 168, height 30, `background: rgba(31,36,46,.30); filter: blur(6px); pointer-events:none`.
- **Hover** (triggered only by the cover element, not the tag/slot): record `transform: translateY(-12px) scale(1.07)`; cast shadow height 44, blur 12px, opacity .7, `transform: translateY(10px) scaleX(1.08)`. Both `180ms cubic-bezier(.2,.7,.2,1)`.

## Buttons
24px tall, padding 0 10px, 13px/400, radius 2px, white-space nowrap.
- Default: #FFFFFF bg, 1px #DBE0E6, text #1F242E; hover bg #F0F2F5.
- Primary ("New playlist"): bg/border #1F242E, text #FFFFFF; hover #384050.

## Design tokens
- Font: Roboto Condensed (400, 700) everywhere.
- Background #F9F9FA · Text #1F242E · Muted #5B6472 · Border #DBE0E6 · Logo placeholder border #B9C1CC.
- Wood: back #E6D6C3 (edge #CDB89F) · board top #A67C58 · board front #8B6243 (hi #B48C69, lo #6B4A32).
- Radius: 2px on all UI. Records are sharp (0).

## State / data
- Per playlist: `name`, `year`, `volumes` (count of Discogs releases), `coverUrl`.
- UI state: `hoveredId` (CSS :hover on the record is enough), container width (ResizeObserver → recompute `per`).
- Click on a record will open Screen 2 ("Selected record") — designed next.

## Files
- `shelf-reference.html` — standalone working reference (no dependencies besides Google Fonts).
- `Shelf Screen.dc.html`, `Mulsa Playlists.dc.html` — original design canvas (needs the design tool runtime; reference only).
