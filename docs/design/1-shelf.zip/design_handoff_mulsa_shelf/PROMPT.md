Implement the Playlists "shelf" screen of Mulsa in our Angular app, following the design handoff in this folder.

- Read `README.md` first: it contains every measurement, color, shadow and the 3D CSS.
- Open `shelf-reference.html` in a browser: it is a working, dependency-free reference. Match it exactly at 1440×900 and 1200×700.
- Keep the existing app style (Roboto Condensed, #F9F9FA background, #1F242E text, #DBE0E6 borders, 2px radius, 24px buttons). Reuse our existing button and header components if they exist.
- Build it as an Angular component (e.g. `PlaylistShelfComponent`) fed by the existing playlists data: name, year, number of volumes, cover image URL. Use the real cover image on the front face.
- Records per shelf: clamp(floor((containerWidth − 96) / 220), 4, 6). Recompute on resize (ResizeObserver).
- Hover state must trigger only on the cover, not on the tag or empty slot space.
- Plain CSS only (perspective, rotateX/rotateY, preserve-3d). No WebGL, no extra libraries.
- Clicking a record should emit a `select` event with the playlist id (the "Selected record" view comes later).
- When done, run the app, check there are no console errors, and compare against `shelf-reference.html` side by side.
