Implement Screen 2 of Mulsa, "Selected record", in our Angular app, on top of the Playlists shelf screen that is already implemented. Follow the design handoff in this folder.

- Read `README.md` first: it has every size, color, shadow, the 3D/flip CSS and the motion timings.
- Open `reference.html` in a browser: it is a working, dependency-free reference. Click a record, flip it, use the arrows, close it. Match it at 1440×900 and 1200×700. `reference.html?open=10` opens a record on load; `?open=11&flip=1` shows the track-list back.
- Do not change the shelf, header or footer; only add the overlay and the click-to-open behaviour.
- Build it as an Angular component (e.g. `SelectedRecordComponent`) shown over the shelf when a record is clicked. Inputs: the playlist list and the selected id. Outputs: `close`, `open(id)`, `setup(id)`.
- Use real data: cover image on the front; back cover image when the playlist has one, otherwise the light grey back with the track list grouped by volume; name, year, volume count, marked and downloaded counts.
- Close with the ×, a click on the dimmed background, or Esc. Previous/next with the arrows and ←/→, wrapping around and resetting to the front.
- Opening animation: FLIP from the clicked shelf record to the centre (Web Animations API or Angular animations). Flip: CSS transform transition with `backface-visibility: hidden`.
- Plain CSS only (perspective, rotateY, preserve-3d, backdrop-filter). No WebGL, no extra libraries.
- When done, run the app, check there are no console errors, and compare against `reference.html` side by side.
