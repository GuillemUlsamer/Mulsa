# Handoff: Mulsa · Selected record (Screen 2)

## Overview
Clicking a record on the Playlists shelf pulls it out to the centre of the window, large, with an info panel to its right. The shelf stays visible behind it, darkened and blurred. From here the user can open the playlist, open its setup, flip the record to see the back, move to the previous/next record, or close. Target sizes: 1440×900 (primary), 1200×700 (must work).

## About the design files
The files in this folder are **design references made in HTML**, not production code. Rebuild the screen in the existing Angular app, on top of the shelf screen that is already implemented. `reference.html` is a dependency-free working version (shelf + overlay; open it in a browser). It is the source of truth for values, 3D CSS and motion. Add `?open=10` to the URL to open a record on load, and `?open=11&flip=1` to see the back with the track list. The `.dc.html` files are the original design canvas (frames 2a–2d) and are for reference only.

## Fidelity
High fidelity. Covers, back covers and track names in the reference are placeholders; use the real data.

## Screen 1 changes included in the reference
Already implemented in the app; listed so the reference matches it: jewel-case edges (top #E8EAED, sides #C3C7CC), front-face shadow `0 10px 18px 2px rgba(31,36,46,.40)`, light board shadow rgba(31,36,46,.16) 22px high, tag 160×40 #F1F2F4 above the board shadow, minimum 4 shelves, boards end 48px from the window edges, header (30px title) and 59px footer.

## Layout
- **Overlay**: covers the whole window, including header and footer.
  - Scrim: `rgba(31,36,46,.40)` + `backdrop-filter: blur(8px)`. Clicking it closes.
  - Close "×": 32×32, top 20px, right 24px. White, 1px #DBE0E6, radius 2px, glyph 22px.
  - Arrows "‹" "›": 40×40, 32px from the left/right edges, vertically centred, same style, glyph 28px.
  - Record (420×420) and panel (320px wide) are centred together as one group, gap 56px, vertically centred.
- **Record** (in a wrapper with `perspective: 1800px`):
  - `transform-style: preserve-3d; transform: rotateX(3deg) rotateY(-8deg)`.
  - Depth 16px. Front face `translateZ(8px)`, back face `rotateY(180deg) translateZ(8px)`, both `backface-visibility: hidden`, `box-shadow: inset 0 0 0 1px rgba(0,0,0,.18)`.
  - Edges, centred and pushed out by `translateZ(210px)`: left `rotateY(-90deg)`, right `rotateY(90deg)`, top `rotateX(90deg)`, bottom `rotateX(-90deg)`. Top #E8EAED; left, right, bottom #C3C7CC.
  - Hinge strip on the front: 14px wide on the left, `rgba(255,255,255,.16)`, right border 1px `rgba(0,0,0,.18)`.
  - Floor shadow: ellipse, 36px inset left/right, 40px high, bottom −34px, `rgba(20,24,32,.50)`, `blur(22px)`.
- **Info panel**: #FFFFFF, 1px #DBE0E6, radius 2px, padding 24px, `box-shadow: 0 12px 32px rgba(20,24,32,.18)`.
  - Name: 32px/700, line-height 34px, `text-wrap: balance`.
  - Subline: "1994 · 2 volumes" ("1 volume" when singular), 16px/400 #5B6472, 6px below the name.
  - Stats, 20px below, 1px #DBE0E6 top border:
    - "Marked songs" → marked count.
    - "Downloaded" → "downloaded / marked".
    - Labels are 13px #5B6472 (nowrap); values are 16px/700 tabular-nums. Rows have 9px vertical padding with a divider between them.
    - Progress bar: 4px tall, track #E6E9ED, fill #1F242E (downloaded ÷ marked).
  - Buttons, 24px below: "Open" (primary #1F242E, white text) and "Setup" (white, 1px #DBE0E6). Both 24px tall, min-width 72px, padding 0 14px, 13px, 6px gap. Hover: #384050 / #F0F2F5.
  - Text button 14px below: "Back cover" (reads "Front cover" when flipped), 13px #1F242E, underline offset 3px, hover #5B6472.
- **Back face**:
  - With a back cover image: the image fills the face (`object-fit: cover`).
  - Without one: background #ECEEF1, padding 24px 24px 20px 34px.
    - Header: name 15px/700 (ellipsis) and year 12px #5B6472, separated from the list by a 1px #C3C7CC rule with 8px padding.
    - Track list in 2 CSS columns (gap 20px, `column-fill: auto`, overflow hidden). Each volume starts with a label "VOL. 1" (10px/700, uppercase, letter-spacing .06em, #5B6472), followed by one line per track: number "01" in #8A93A0 tabular-nums, then "Artist – Title". Track lines are 10.5px with 14px line-height and ellipsis. Volumes are separated by 8px.

## Interactions & motion
- **Open** (click a record on the shelf): FLIP from the shelf record's rect to the centre stage (translate + scale), 380ms `cubic-bezier(.2,.7,.2,1)`. The scrim fades 0→1 over 200ms. The panel fades in and slides from translateX(12px), 200ms, starting at 180ms. Shelf hover is suppressed while open.
- **Close** (×, scrim click, Esc): reverse the FLIP back to the shelf slot, 260ms. The panel fades out in 120ms and the scrim fades out in 260ms.
- **Flip** ("Back cover"): transition `transform 600ms cubic-bezier(.45,.05,.25,1)` between `rotateY(-8deg)` and `rotateY(172deg)`.
- **Prev / next** (arrows, ← / →): wraps around and resets to the front without animating the flip. The record fades in and slides 24px from the direction of travel, 240ms.
- **Open / Setup**: go to the existing playlist and setup screens.

## State
- `selectedId` (null = shelf only), `flipped` (boolean, reset on open/prev/next).
- Per playlist: `name`, `year`, `volumes` (each with its track list), `markedCount`, `downloadedCount`, `coverUrl`, `backCoverUrl` (optional).

## Design tokens
- Font: Roboto Condensed 400/700 (covers in the reference use 900 italic as placeholder only).
- Text #1F242E · Muted #5B6472 · Faint #8A93A0 · Border #DBE0E6 · Surface #FFFFFF · App bg #F9F9FA · Back fallback #ECEEF1 · Bar track #E6E9ED.
- Jewel case: top #E8EAED, sides #C3C7CC.
- Scrim rgba(31,36,46,.40) + blur 8px.
- Radius 2px on all UI; records are sharp.

## Files
- `reference.html`: standalone working reference (shelf + selected record + flip).
- `Mulsa Playlists.dc.html`, `Shelf Screen.dc.html`, `support.js`: original design canvas (frames 2a–2d). Reference only.
