Implement Screen 4 (Settings) and Screen 5 (Playlist setup, both modes) of Mulsa in our Angular app, following the design handoff in this folder. Screens 1–3 are already implemented.

- Read `README.md` first: layout, sizes, spacing, copy and colours for each screen.
- Open `reference.html` in a browser to see each screen working: `?screen=settings` (try `&google=0&advanced=1&error=1`), `?screen=new`, `?screen=edit&name=Hardcore%20Overdose` (press "Import list"). Match it at 1440×900 and 1200×700.
- Full-window layouts, no modal cards. Reuse the app's existing header ("‹ Playlists" + 30px title), 40px status footer, inputs (26px, 1px #ADB5BD) and buttons (24px).
- Settings: form on the left (groups Soulseek / Folders / Google, "Advanced" collapsed by default with credentials.json), Cancel / Save at the bottom. On the right, the kangaroo PNG (transparent) placed straight on the page background, with no divider or panel colour. The image file will be supplied; leave a clearly named asset path.
- Setup mode A (`/setup`): Name * + Create, and on the right a 40%-wide #ECEEF1 panel with the blank jewel case showing the typed name live.
- Setup mode B (`/setup/:name`): "Fill the volumes" on the left (60%), "Volumes" on the right (40%). Both column heads must be identical (76px, same title and subline sizes) so they line up.
  - Wire Import list, Set up and the per-volume Release ID + Import to the existing backend calls.
  - Show progress in the activity area and in the footer ("Importing release 3/12…").
  - Reject master IDs or URLs (`/master/`) with a clear error.
- Validation: required fields marked with a red "*"; show errors in #D93025 in the footer line.
- When done, run the app, check there are no console errors, and compare against `reference.html` side by side.
