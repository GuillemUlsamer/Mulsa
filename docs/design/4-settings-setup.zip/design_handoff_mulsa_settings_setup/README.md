# Handoff: Mulsa · Settings (Screen 4) and Playlist setup (Screen 5)

## Overview
These are two full-window form screens in the same style as the shelf and the runner. There are no centred cards or modals.
- **Settings** (Screen 4): the form on the left and the kangaroo illustration on the right, placed straight on the page background.
- **Playlist setup** (Screen 5) has two modes:
  - **A, new playlist** (`/setup`): the form on the left and a blank jewel case on the right that shows the typed name.
  - **B, existing playlist** (`/setup/:name`): "Fill the volumes" on the left (60%) and the "Volumes" list on the right (40%).

Target sizes: 1440×900 (primary), 1200×700 (must work).

## About the design files
These are **design references made in HTML**, not production code. Rebuild them in the existing Angular app using its header, footer, buttons and inputs.
- `reference.html` is a dependency-free working version. Open it with:
  - `?screen=settings` (add `&google=0`, `&advanced=1`, `&error=1` to see those states).
  - `?screen=new`.
  - `?screen=edit&name=Hardcore%20Overdose` (press "Import list" to see the import progress; `&error=1` shows the error line).
- The `.dc.html` files are the design canvas (frames 4c, 4d, 5d, 5e, 5f) and are for reference only.

## Fidelity
High fidelity. Release names, IDs and help copy are sample content.

## Shared frame
- **Header**: 64px, padding 0 24px, 1px #DBE0E6 bottom rule. "‹ Playlists" (24px button) then the 30px/700 title, 12px gap.
  - Titles: "Settings", "New playlist", or the playlist name.
  - Mode B adds "Open in Drive" and **Run** (primary) on the right, 6px gap.
- **Footer**: 40px, padding 0 24px, 1px #DBE0E6 top rule. One 13px #5B6472 status line ("Setting up…", "Importing release 3/12…", summaries). Errors are #D93025.
- **Controls**:
  - Input: 26px, #FFFFFF, 1px #ADB5BD, radius 2px, padding 0 8px, 14px. Focus border #1F242E. Placeholder #8A93A0. Numbers use tabular-nums.
  - Buttons: 24px, 13px, radius 2px. Default: white with 1px #DBE0E6, hover #F0F2F5. Primary: #1F242E with white text, min-width 72px, padding 0 14px, hover #384050.
  - Input + button: flex row, 6px gap, input flexes.
  - Text button: 13px, underlined (offset 3px), hover #5B6472.
  - Required marker: "*" in #D93025.

## Screen 4 · Settings
- Body: two equal halves (flex 1 / 1) on the #F9F9FA page. **No divider and no background on the right half.**
- **Left (form)**: scrolls; content max-width 600px, padding 40px 48px 48px 72px.
  - Groups "Soulseek", "Folders", "Google". Each title is 16px/700 (20px line) with a 1px #DBE0E6 rule 8px below it. The grid starts 16px under the rule, and groups are 36px apart.
  - Grid: 140px | 1fr, column gap 16px, row gap 18px. Labels 14px, line-height 26px (aligned with the input). Help text 12px/16px #5B6472, 4px under the control.
  - Soulseek:
    - Username * (help: "The account Mulsa uses to search and download.").
    - Password * (placeholder "(unchanged)" once configured; help: "Leave empty to keep the current password.").
    - Port: 100px input (help: "Listening port. Change it only if the default is blocked.").
  - Folders:
    - Music folder * with Browse… (help: "Finished songs are saved here, one folder per playlist and volume.").
    - Shared folder with Browse… (placeholder "Not shared"; help: "Folder other Soulseek users can browse. Optional.").
  - Google:
    - Account, connected: "Connected" 14px/700 #1E8E5A, then the email 14px #5B6472 (ellipsis), then a **Sign out** button.
    - Account, signed out: a "Sign in with Google" button.
    - Help: "Needed to read and create playlist sheets in your Drive."
    - Below it, an "Advanced" text button (reads "Hide advanced" when open). It reveals the credentials.json row (input + Browse…; help: "Google API client file. Only needed with your own Google Cloud project.").
  - Actions: Cancel and Save, right-aligned, 36px under the last group, above a 1px #DBE0E6 rule with 16px padding-top.
- **Right (kangaroo)**: a transparent PNG placed straight on the page.
  - Box inset 40px top, 48px left/right, 72px bottom. Use `object-fit: contain`, anchored bottom-centre.
  - It may shrink with the window; hide it if the half is narrower than ~360px.

## Screen 5 · Setup
### Mode A · New playlist (`/setup`)
- **Left**: same form column as Settings. Group title "New playlist", then one row:
  - Name * with the **Create** button (primary) beside the input.
  - Help: "Created in your Drive folder "Playlists" with a Releases sheet and one volume."
- **Right**: **40% wide**, the same as the Volumes column in mode B. #ECEEF1 with a 1px #DBE0E6 left border, content centred.
  - A blank jewel case, 360×360. It uses the same case CSS as Screen 2:
    - Perspective 1800px.
    - `rotateX(3deg) rotateY(-8deg)`.
    - Edges 16px, `translateZ(180px)`: top #E8EAED, others #C3C7CC.
    - Front `translateZ(8px)`, #ECEEF1, inset 0 0 0 1px rgba(0,0,0,.12), padding 28px 28px 24px 40px.
    - Hinge strip 14px, rgba(255,255,255,.4), 1px rgba(0,0,0,.12) right border.
  - Name: shows what is typed in Name, live. 34px, 900 italic, uppercase, line-height .92, balanced. When empty it shows "Untitled playlist" in #8A93A0.
  - Bottom line: "Vol. 1" left, "No cover yet" right, 12px #5B6472, under a 1px #C3C7CC rule.
  - Floor shadow: rgba(20,24,32,.30), blur 20px.

### Mode B · Existing playlist (`/setup/:name`)
- **Column heads are identical** so they line up: 76px tall, 1px #D5D9DE bottom rule, vertically centred.
  - Title 20px/700 (24px line).
  - One line 13px/18px #5B6472 (nowrap, ellipsis).
- **Left, "Fill the volumes"** (60%, #F9F9FA, no card, side padding 48px):
  1. Head: "Fill the volumes" / "Import a whole Discogs list, or create empty volumes and import one release into each."
  2. Options band: grid 1fr | auto | 1fr, column gap 32px, padding 28px 48px 32px, 1px #DBE0E6 bottom rule. Each option has a 16px/700 title, a 12px help line 4px below, and controls 14px below.
     - **Import a Discogs list**:
       - Help: "One volume per release in the list. Replaces the current volumes."
       - List ID input (max 180px) and **Import list** (primary).
     - Middle: vertical 1px #DBE0E6 lines with "OR" (12px/700, letter-spacing .08em, #8A93A0).
     - **Set up volumes**:
       - Help: "Creates empty volumes V 1..N with headers; then import a release into each one."
       - Second help line in #1F242E: "Use a Discogs **release** ID (discogs.com/release/…), not a master ID (discogs.com/master/…)."
       - Count input (80px) and **Set up**.
  3. Activity: fills the rest, padding 20px 48px 24px.
     - Title 16px/700: "Recent imports", "Importing release 3/12" or "Import finished", with the % on the right in 13px #5B6472.
     - While importing, a 4px bar (#E6E9ED track / #1F242E fill) 8px below the title.
     - Rows: 26px, 13px, grid 36px | 1fr | auto, gap 12px, 1px #EDEFF2 rules. Content: "V n", then "Release name · release 104772", then the result.
     - Results: "24 tracks" #1E8E5A 700; errors such as "Not found on Discogs" or "This is a master, not a release" #D93025 700; "Importing…" #5B6472.
- **Right, "Volumes"** (40%, #ECEEF1, 1px #DBE0E6 left border, side padding 32px):
  - Head: "Volumes" / "12 volumes · 191 tracks".
  - Rows: min-height 38px (holds the 26px input), 1px #DDE0E4 rule. Grid 36px | 1fr | 120px | auto, gap 8px.
    - "V 3": 12px #8A93A0 tabular-nums.
    - Release name: 14px (ellipsis), followed by "n tracks" 12px #8A93A0 with an 8px gap. An empty volume shows "Empty" in #8A93A0.
    - "Release ID" input (120px) and an **Import** button.
  - The list scrolls.
- **Validation**: if the pasted ID or URL is a master (`/master/`), reject it in the activity list or footer with "This is a master, not a release".

## Design tokens
- Font: Roboto Condensed 400/700 (900 italic only for the case name).
- Bg #F9F9FA · Text #1F242E · Muted #5B6472 · Faint #8A93A0 · Border #DBE0E6 · Input border #ADB5BD · Paper #ECEEF1 · Rules #D5D9DE / #DDE0E4 / #EDEFF2.
- Connected / success #1E8E5A · Error and required #D93025.
- Radius 2px. No icons except the kangaroo.

## Files
- `reference.html`: standalone working reference (`?screen=settings|new|edit`).
- `Mulsa Playlists.dc.html`, `Forms Screens v2.dc.html`, `image-slot.js`, `support.js`: design canvas. Reference only.
